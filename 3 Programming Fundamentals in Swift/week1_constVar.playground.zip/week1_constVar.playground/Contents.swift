import UIKit

let dayOFWeek = "Monday"
let dailyTemperature = 75
let weeklyTemperature = 75

var temperature = 70

print("Toda is \(dayOFWeek)")
print("Temperature on \(dayOFWeek) is \(dailyTemperature)℉")

temperature = 80
print("The temperature on \(dayOFWeek) is \(temperature)℉")

temperature = weeklyTemperature

print("The average temperature this week is \(temperature)℉")

